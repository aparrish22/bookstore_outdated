<?php
	$connection = mysqli_connect("localhost","root","");
	
	if(!$connection) {
		die('Could not connect: ' . mysqli_error());
	}
     
     
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>

<?php
	$connection = mysqli_connect("localhost","root","");
	
	if(!$connection) {
		die('Could not connect: ' . mysqli_error());
	}
     

	mysqli_select_db($connection,"book_store_v4");
	 
    $query = $_GET['query']; 
    // gets value sent over search form
     
    $min_length = 0;
    // you can set minimum length of the query if you want
     
    if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $query = mysqli_real_escape_string($connection,$query);
        // makes sure nobody uses SQL injection
         
        $raw_results = mysqli_query($connection,"SELECT * FROM book WHERE (`title` LIKE '%".$query."%') OR (`isbn` LIKE '%".$query."%') OR (`author` LIKE '%".$query."%')") or die(mysqli_error($connection));
             
        // user is able to search for title, ISBN, or author name
         
        // '%$query%' is what we're looking for, % means anything, for example if $query is Hello
        // it will match "hello", "Hello man", "gogohello", if you want exact match use `title`='$query'
        // or if you want to match just full word so "gogohello" is out use '% $query %' ...OR ... '$query %' ... OR ... '% $query'
         
        if(mysqli_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
            while($results = mysqli_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop

         
             	if (!is_null($results['edition'])) {
	                echo "<p><h3>".$results['title'].
							"</h3><br>"."Author: ".$results['author'].
							"</br><br>"."ISBN: ".$results['isbn'].
							"</br><br>"."Publisher: ".$results['publisher'].
							"</br><br>"."Edition: ".$results['edition'].
							"</br><br>"."Price: ".$results['price'].
							"</br><br></p>";
             	} else {
             		echo "<p><h3>".$results['title'].
							"</h3><br>"."Author: ".$results['author'].
							"</br><br>"."ISBN: ".$results['isbn'].
							"</br><br>"."Publisher: ".$results['publisher'].
							"</br><br>"."Edition: N/A".
							"</br><br>"."Price: ".$results['price'].
							"</br><br></p>";
             	}

	            // posts results 
            }
             
        }
        else{ // if there is no matching rows do following
            echo "No results";
        }
         
    }
	
	else if($min_length == 0){
		
		$all_results = mysqli_query($connection,"SELECT * FROM book") or die(mysqli_error($connection));
		
		if(mysqli_num_rows($all_results) > 0) {
			while($results = mysqli_fetch_array($all_results)){
				echo "<p><h3>".$results['title'].
						"</h3><br>"."Author: ".$results['author'].
						"</br><br>"."ISBN: ".$results['isbn'].
						"</br><br>"."Publisher: ".$results['publisher'].
						"</br><br>"."Edition: ".$results['edition'].
						"</br><br>"."Price: ".$results['price'].
						"</br><br></p>";
			}
		}
	}
	
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }
?>

	<form action="index.php">
		<button type="submit">Go to Search</button>
	</form>

</body>
</html>