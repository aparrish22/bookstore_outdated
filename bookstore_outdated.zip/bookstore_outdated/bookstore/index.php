<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search</title>
<!--    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> -->
	<link rel="stylesheet" type="text/css" href="style.css"/>


	<!-- Bootstrap -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body> 
<!-- old search... no formatting 
	<div>
	    <form action="search.php" method="GET">
	        <input type="text" name="query" />
	        <input type="submit" value="Search" />  
	    </form>
	</div>
--> 

		    <!-- NAVBAR -->
	
			<form class="navbar-form navbar-left" action="search.php" method="GET">
				<div class="input-group">
					<div class="panel panel-default">
						<div class="panel-body">
							<input type="text" name="query" class="form-control" placeholder="Search">
							<div class="input-group-btn">
								<button class="btn btn-default" type="submit" value="Search">
									<i class="glyphicon glyphicon-search"></i>
								</button>
							</div>
						</div>
					</div>
				</div>
			</form>
		
		

   
</body>
</html>